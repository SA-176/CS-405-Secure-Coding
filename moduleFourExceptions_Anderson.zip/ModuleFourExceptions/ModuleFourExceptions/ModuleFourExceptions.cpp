// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>

//created the CustomException class extended from std::Exception
struct CustomException : public std::exception {
    //assign the message to what()
    virtual const char* what() const throw() {
        return "This is the standard exception message";
    }
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    std::cout << "Running Even More Custom Application Logic." << std::endl << std::endl;

    //throwing an runtime_error exception
    throw std::runtime_error("Exception thrown: Runtime Error");

    return true;
}
void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing

    //using try/catch to catch the exceptions
    try {
        std::cout << "Running Custom Application Logic." << std::endl << std::endl;
        //use if to send message if it succeeds
        if (do_even_more_custom_application_logic()) {

            std::cout << "Even More Custom Application Logic Succeeded." << std::endl << std::endl;

        }
    }
    //catch exceptions
    catch (const std::exception& ex) {

        //print message
        std::cout << "Standard Exception caught" << std::endl << std::endl;
        //print exception
        std::cout << ex.what() << std::endl << std::endl;

    }
        

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main

    //throwing the custom exception to be caught
    throw CustomException();

    std::cout << "Leaving Custom Application Logic." << std::endl << std::endl;

}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception

    //use an if check to see if the denominator is zero
    if (den == 0) {
        //if the den is zero throw invalid argument exception
        throw std::invalid_argument("Invalid argument: can't divide by Zero");
    }

    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.
    
    //try/catch that won't find the invalid arugument exception
    std::cout << "Divide by 2" << std::endl;
    try {
        float numerator = 10.0f;
        float denominator = 2;//set to 2 to avoid exception

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl << std::endl;
    }
    //catch to catch any invalid argument exception
    catch (const std::invalid_argument& ex) {
        //print exception message
        std::cout << ex.what() << std::endl << std::endl;
    }
    //try/catch that will throw the invalid arguement exception
    std::cout << "Divide by 0" << std::endl;
    try {
        float numerator = 10.0f;
        float denominator = 0; //set to zero to find exception

        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl << std::endl;
    }
    //catch to catch any invalid argument exception
    catch (const std::invalid_argument& ex) {
        //print exception message
        std::cout << ex.what() << std::endl << std::endl;
    }
    
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception 
    //  that wraps the whole main function, and displays a message to the console.

    //using an try/catch to find the exceptions
    try {
        do_division();
        do_custom_application_logic();
    }
    //catch the custom exceptions that have been derived from standard exceptions
    catch (const CustomException& ex) {
        std::cout << ex.what() << std::endl << std::endl;
    }
    //catch the standard exceptions
    catch (const std::exception& ex) { 
        std::cout << ex.what() << std::endl << std::endl;
    }
    //catch other exceptions
    catch (...) {
        std::cout << "An exception has been caught" << std::endl << std::endl;
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu